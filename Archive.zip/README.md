# ViJIPay
[VijiPay - Secure Thirdparty Escrow Services for Seamless Transactions on JIJI Marketplace]

- Ensuring you don't get scammed when you buy or sell on JIJI buy protecting your transaction
- Verified Seller and Buyer Profiles
- User-Friendly Interface
- Efficient and Fast
- Efficient Dispute Resolution
- Advanced Scam Detection